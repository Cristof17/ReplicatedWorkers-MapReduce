

public interface ReduceResultFinishedCallback {

	public void reduceResultReady(ReduceResult result);
	
}

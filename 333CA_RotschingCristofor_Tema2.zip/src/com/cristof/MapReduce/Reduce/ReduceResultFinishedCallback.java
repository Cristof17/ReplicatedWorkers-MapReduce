package com.cristof.MapReduce.Reduce;

public interface ReduceResultFinishedCallback {

	public void reduceResultReady(ReduceResult result);
	
}

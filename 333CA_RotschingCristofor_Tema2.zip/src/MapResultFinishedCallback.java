public interface MapResultFinishedCallback {

	public void mapResultReady(MapResult result, int workerID , int fragmentID);
	
}

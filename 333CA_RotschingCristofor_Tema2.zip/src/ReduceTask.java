

import java.util.ArrayList;

public class ReduceTask {
	
	public ArrayList<MapResult> mapResults;
	
	public ReduceTask(ArrayList<MapResult> mapResults){
		this.mapResults = mapResults;
	}

}

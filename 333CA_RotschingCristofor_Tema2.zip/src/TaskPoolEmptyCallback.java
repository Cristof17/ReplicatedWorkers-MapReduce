

public interface TaskPoolEmptyCallback {

	public void poolReady(boolean ready);
	
}
